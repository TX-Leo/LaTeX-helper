from utils.fileio import *

if __name__ == '__main__':
    print(get_tex_list_recursive('.'))